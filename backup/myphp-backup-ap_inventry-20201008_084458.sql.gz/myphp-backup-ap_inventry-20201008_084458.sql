CREATE DATABASE IF NOT EXISTS `ap_inventry`;

USE `ap_inventry`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `company_account`;

CREATE TABLE `company_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  `company_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `agent_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `buy_amount` float NOT NULL,
  `received` float NOT NULL,
  `date_sh` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `company_account` VALUES (9,1212,"sony","ahmad",0,850,"09/07/1399"),
(10,1212,"sony","ahmad",200,0,"09/07/1399"),
(11,1212,"gilrate","ahmad",50000,30000,"12/07/1399");


DROP TABLE IF EXISTS `item_expenses`;

CREATE TABLE `item_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(10) NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `price1` float NOT NULL,
  `date_sh` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `item_expenses` VALUES (1,1,"                                                                                                                                                مصرف نان صبح 3 دانه برگر                                                                                                                                          ",10,50,"28/07/1399",true),
(2,2,"برداشت روف خان ",1,500,"28/06/1399",true);


DROP TABLE IF EXISTS `item_store`;

CREATE TABLE `item_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `mount` float NOT NULL,
  `buy_price` float NOT NULL,
  `sell_price` float NOT NULL,
  `date` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `barcode` (`barcode`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `item_store` VALUES (12,2406805,"camera 3 MP Indoor",102,120,130,"09/07/1399"),
(14,546465,"lebas ",100,120,200,"17/07/1399"),
(15,122345,"teflana",100,100,200,"17/07/1399");


DROP TABLE IF EXISTS `licence`;

CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `mac` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `licence` VALUES (1,121233,"F0-1F-AF-3A-FE-28","used"),
(2,223345,"","");


DROP TABLE IF EXISTS `new_company`;

CREATE TABLE `new_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `address` text COLLATE utf8mb4_persian_ci NOT NULL,
  `date_sh` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `new_company` VALUES (4,"sony","---","---","--","---","09/07/1399"),
(5,"gilrate","---","----","--","--","12/07/1399");


DROP TABLE IF EXISTS `plus_item`;

CREATE TABLE `plus_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `mount` float NOT NULL,
  `buy_price` float NOT NULL,
  `sell_price` float NOT NULL,
  `date` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `plus_item` VALUES (1,4607006670129,"evica",100,120,200,"28/06/1399"),
(2,4607006670129,"evica",100,125,210,"28/06/1399"),
(3,4607006670129,"evica",1,100,200,"28/06/1399"),
(4,4607006670129,"evica",2,80,0,"28/06/1399"),
(5,8699525043948,"pandev",100,120,140,"28/07/1399"),
(6,8699525014115,"motis",100,80,120,"28/06/1399"),
(7,8904184702328,"maidprost",50,40,80,"28/06/1399"),
(8,8699525014115,"motis",40,105,150,"28/06/1399"),
(9,8699525014115,"motis",1,100,0,"28/06/1399"),
(10,4607006670129,"evica",1,90,0,"28/06/1400"),
(11,8699525043948,"pandev",50,150,180,"28/07/1399"),
(12,8904030852221,"dexamethasone",100,10,30,"29/06/1399"),
(13,6923723120012,"br reader",100,100,150,"31/06/1399"),
(14,1212,"ah",10,10,15,"09/07/1399"),
(15,23467,"aa",100,120,150,"09/07/1399"),
(16,1212,"ah",10,120,130,"09/07/1399"),
(17,8904030852221,"dexamethasone",50,40,60,"09/07/1399"),
(18,8699525014115,"motis",1,35,0,"09/07/1399"),
(19,4545,"camera 3 MP Indoor",100,15,30,"09/07/1399"),
(20,2406808,"Cam 329 HD 4 MP",100,50,51,"09/07/1399"),
(21,2406808,"Cam 329 HD 4 MP",2,51,0,"09/07/1399"),
(22,4545,"camera 3 MP Indoor",2,51,0,"09/07/1399"),
(23,2406805,"camera 3 MP Indoor",10,120,130,"09/07/1399"),
(24,2406805,"camera 3 MP Indoor",2,130,0,"09/07/1399"),
(25,2406805,"camera 3 MP Indoor",2,120,0,"09/07/1399"),
(26,546465,"lebas ",100,120,200,"17/07/1399"),
(27,122345,"teflana",100,100,200,"17/07/1399");


DROP TABLE IF EXISTS `stored_item`;

CREATE TABLE `stored_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_detail` text COLLATE utf8mb4_persian_ci NOT NULL,
  `to_detail` text COLLATE utf8mb4_persian_ci NOT NULL,
  `invoice_detail` text COLLATE utf8mb4_persian_ci NOT NULL,
  `barcode` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `item_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `mount` float NOT NULL,
  `sell_price` float NOT NULL,
  `date` text COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  `password` varchar(30) COLLATE utf8mb4_persian_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `lastname` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `authority` int(5) NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

INSERT INTO `users` VALUES (12,"admin","YWRtaW4=","Doctor","Nemat",100,""),
(13,"khwaja","cmF3b2YxMjM=","khwaja","rawof",50,"");


SET foreign_key_checks = 1;
